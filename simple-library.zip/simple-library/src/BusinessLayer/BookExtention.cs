// using DataAccess;

// namespace BusinessLayer;

// public static class SignUpDTOExtensions
// {
//     public static BookModel ToBookModel(this BookDTO bookDTO)
//         => new()
//         {
//             Name = bookDTO.Name,
//             FilePath = bookDTO.FilePath,
//             Price = bookDTO.Price,
//             Authors = bookDTO.Authors,
//             Category = bookDTO.Category
//         };
// }